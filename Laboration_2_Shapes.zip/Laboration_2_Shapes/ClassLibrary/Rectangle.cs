﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Rectangle : Shape2D
    {
        Vector2 Size;               //Detta ist för det längst ner?

        public override Vector3 Center { get; }
        public override float Area
        {
            get { return (Size.X * Size.Y); }
        }

        public override float Circumference
        {
            get { return (Size.X * 2) + (Size.Y * 2); }
        }

        public Rectangle(Vector2 center, Vector2 size)
        {
            Center = new Vector3(center, 0);
            Size = size;
        }

        //Assigns height and width to the same value
        public Rectangle(Vector2 center, float width)
        {
            Center = new Vector3(center, 0);
            Size.X = width;
            Size.Y = width;
        }

        public bool IsSquare
        {
            get
            {
                if (Size.X == Size.Y)
                { return true; }
                else
                { return false; }
            }
        }

        public override string ToString()
        {
            return $"Rectangle @(X = {Center.X:0.00}, Y = {Center.Y:0.00}) [w = {Size.X:0.00}, h = {Size.Y:0.00}] " +
                $"[Is it a square?] {IsSquare}!";
        }
    }
}
