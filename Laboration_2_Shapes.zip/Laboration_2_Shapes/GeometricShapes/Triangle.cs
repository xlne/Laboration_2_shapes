﻿using System.Collections;
using System.Numerics;

namespace ClassLibrary
{
    public class Triangle : Shape2D, IEnumerable, IEnumerator
    {
        Vector2 P1, P2, P3;
        int positionOfList;
        public override Vector3 Center
        {
            get
            {
                return new Vector3((P1.X + P2.X + P3.X) / 3.0f,
                             (P1.Y + P2.Y + P3.Y) / 3.0f, 0);
            }
        }

        public override float Area
        {
            get
            {
                return (P1.X * (P2.Y - P3.Y) +
                        P2.X * (P3.Y - P1.Y) +
                        P3.X * (P1.Y - P2.Y)) / 2f;
            }
        }

        public override float Circumference
        {
            get
            {
                return (Vector2.Distance(P1, P2) +
                        Vector2.Distance(P1, P3) +
                        Vector2.Distance(P2, P3));
            }
        }

        public object Current { get { return Current; } }

        public Triangle(Vector2 p1, Vector2 p2, Vector2 p3)
        {
            listPoints[0] = p1;
            listPoints[1] = p2;
            listPoints[2] = p3;
            P1 = p1;
            P2 = p2;
            P3 = p3;
        }

        public override string ToString()
        {
            return $"Triangle @(X = {Center.X:0.00}, Y = {Center.Y:0.00}): \tP1 = {P1:0.00}, P2 = {P2:0.00}, P3 = {P3:0.00}";
        }

        public Vector2[] listPoints = new Vector2[3];

        public bool MoveNext()
        {
            positionOfList++;
            return positionOfList < listPoints.Length;
        }

        public void Reset()
        {
            positionOfList = -1;
        }

        public IEnumerator GetEnumerator()
        {
            return listPoints.GetEnumerator();
        }
    }
}
