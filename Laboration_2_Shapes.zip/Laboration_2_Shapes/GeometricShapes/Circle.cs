﻿using System;
using System.Numerics;

namespace ClassLibrary
{
    public class Circle : Shape2D
    {
        private readonly float Radius;
        public override Vector3 Center { get; }

        public override float Area
        {
            get { return (float)(Math.PI * Math.Pow(Radius, 2)); }
        }

        public override float Circumference
        {
            get { return (float)(Math.PI * 2 * Radius); }
        }

        public Circle(Vector2 center, float radius)
        {
            Center = new Vector3(center, 0);
            Radius = radius;
        }

        public override string ToString()
        {
            return $"Circle @(X = {Center.X:0.00}, Y = {Center.Y:0.00}): \t[r = {Radius:0.00} cm]";
        }
    }
}
