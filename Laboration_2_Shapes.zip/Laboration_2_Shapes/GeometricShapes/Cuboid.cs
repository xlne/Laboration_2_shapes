﻿using System.Numerics;

namespace ClassLibrary
{
    public class Cuboid : Shape3D
    {
        public Vector3 size;
        public override Vector3 Center { get; }

        //Height, width, depth
        public Cuboid(Vector3 center, Vector3 size)
        {
            this.size = size;
            Center = center;
        }

        //Assigns height, width and depth to the same value
        public Cuboid(Vector3 center, float width)
        {
            Center = center;                            
            size = new Vector3(width);                  
        }

        public override float Volume
        {
            get { return (size.X * size.Y * size.Z); }
        }

        public override float Area
        {
            get
            {
                return (2 * (size.X * size.Y) +
                       (2 * (size.X * size.Z)) +
                       (2 * (size.Y * size.Z)));
            }
        }

        public bool IsCube
        {
            get
            {
                if (size.X == size.Y && size.X == size.Z)
                { return true; }
                else
                { return false; }
            }
        }

        public override string ToString()
        {
            return $"Cuboid @(X = {Center.X:0.00}, Y = {Center.Y:0.00}, Z = {Center.Z:0.00}) [w = {size.X:0.00}, " +
                $"h = {size.Y:0.00}, l = {size.Z:0.00}] [Is it a cube?] {IsCube}!";
        }
    }
}
