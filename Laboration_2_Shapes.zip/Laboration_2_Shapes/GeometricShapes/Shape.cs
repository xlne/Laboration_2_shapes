﻿using System;
using System.Numerics;

namespace ClassLibrary
{
    public abstract class Shape
    {
        private static Random rand = new Random();
        public abstract Vector3 Center { get; }
        public abstract float Area { get; }

        //Generate shape with random values to the center        
        public static Shape GenerateShape()
        {
            return GenerateShape(new Vector3((float)rand.NextDouble() * 100,
                                             (float)rand.NextDouble() * 100,
                                             (float)rand.NextDouble() * 100));
        }

        //Values for center is  passed in, the other values being randomized
        public static Shape GenerateShape(Vector3 position) 
        {
            int nr = 100;
            switch (rand.Next(0, 7))
            {
                case 0:
                    return new Circle(new Vector2(position.X, position.Y), (float)rand.NextDouble() * nr);
                case 1:
                    return new Rectangle(new Vector2(position.X, position.Y), new Vector2((float)rand.NextDouble() * nr, (float)rand.NextDouble() * nr));
                case 2:
                    return new Rectangle(new Vector2(position.X, position.Y), (float)rand.NextDouble() * nr);
                case 3:
                    return GenerateTriangle(new Vector2(position.X, position.Y));
                case 4:
                    return new Cuboid(new Vector3(position.X, position.Y, position.Z), new Vector3((float)rand.NextDouble() * nr, (float)rand.NextDouble() * nr, (float)rand.NextDouble() * nr));
                case 5:
                    return new Cuboid(new Vector3(position.X, position.Y, position.Z), (float)rand.NextDouble() * nr);
                default:
                    return new Sphere(new Vector3(position.X, position.Y, position.Z), (float)rand.NextDouble() * nr);
            }
        }

        public static Triangle GenerateTriangle(Vector2 center)
        {
            //Calculate vertex3: (sumVertices - vertex1 - vertex2)            
            var rand = new Random();
            var sumVertices = center * 3f;
            var vertex1 = new Vector2(x: (float)rand.NextDouble() * 100, y: (float)rand.NextDouble() * 100);
            var vertex2 = new Vector2(x: (float)rand.NextDouble() * 100, y: (float)rand.NextDouble() * 100);

            while (vertex1 == vertex2)
                vertex2 = new Vector2(x: (float)rand.NextDouble() * 100, y: (float)rand.NextDouble() * 100);

            Vector2 vertex3 = (sumVertices - vertex1 - vertex2);

            return new Triangle(vertex1, vertex2, vertex3);
        }
    }
}
