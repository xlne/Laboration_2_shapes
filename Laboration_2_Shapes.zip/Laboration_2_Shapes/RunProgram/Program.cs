﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace RunProgram
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Program prog = new Program();

            //A list which loops through all the shapes, for each index but the centerpoint 
            List<Shape> Shapes = new List<Shape>();
            for (int i = 0; i < 20; i++)
            {
                Shapes.Add(Shape.GenerateShape());
            }

            //Print shapes with randomized generated values for all positions
            Console.WriteLine("\t\t-------------------------------------------------------------------");
            Console.WriteLine("\t\t\tThese shapes have randomized generated values for all positions:");
            Console.WriteLine("\t\t-------------------------------------------------------------------");
            prog.PrintValues(Shapes);

            List<Shape> Shapes2 = new List<Shape>();
            for (int i = 0; i < 20; i++)
            {
                Shapes2.Add(Shape.GenerateShape(new Vector3(3f, 4f, 5f)));
            }

            //Print shapes with in advance assigned values
            Console.WriteLine("\t\t-------------------------------------------------------------------");
            Console.WriteLine("\t\t\tThese shapes have in advace assigned values:");
            Console.WriteLine("\t\t-------------------------------------------------------------------");

            prog.PrintValues(Shapes2);

            Console.ReadKey();
        }

        public void PrintValues(List<Shape> ShapeList)
        {
            float circumTriangles = 0;
            float averageAreaOfAllShapes = 0;
            float LargestVolume_3D = 0;
            string LargestShape = "";
            Shape3D shape3D;

            int round = 1;
            foreach (var shape in ShapeList)
            {
                if (shape is Triangle)
                {

                    var triangle = shape as Triangle;
                    circumTriangles += triangle.Circumference;
                    Console.WriteLine("-----------------------------------------");
                    Console.WriteLine($"Nr {round++}: {triangle}");

                    foreach (var trianglePoints in triangle)
                    {
                        Console.WriteLine(trianglePoints);
                    }
                }
                else
                {
                    Console.WriteLine("-----------------------------------------");
                    Console.WriteLine($"Nr {round++}: {shape}");
                }
                averageAreaOfAllShapes += shape.Area;

                if (shape is Shape3D)
                {
                    shape3D = shape as Shape3D;
                    if (LargestVolume_3D < shape3D.Volume)
                    {
                        LargestVolume_3D = shape3D.Volume;
                        LargestShape = shape3D.ToString(); //Göra if-satser, shape is Cuboid, Cube, Sphere
                    }
                }
            }
            Console.WriteLine();
            Console.WriteLine("Total circumference for all triangles are: {0} cm.", circumTriangles);
            Console.WriteLine("Average area is: {0} cm\u00B2.", averageAreaOfAllShapes / 20);
            Console.WriteLine("{0} cm\u00B3 is the biggest volume. And it is a {1}", LargestVolume_3D, LargestShape);             //shape3D kan inte skriva ut vilkent typ av form

            Console.WriteLine();
            Console.WriteLine();
        }
    }
}